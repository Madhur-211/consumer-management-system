import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { CustomField } from '../models/custom-field.model';
import { ConsumerCustomFieldValue } from '../models/consumer-custom-field-value.model';

@Injectable()
export class CustomFieldsService {
  constructor(
    @InjectModel(CustomField) private customFieldModel: typeof CustomField,
    @InjectModel(ConsumerCustomFieldValue)
    private customFieldValueModel: typeof ConsumerCustomFieldValue,
  ) {}

  async createCustomField(data: any) {
    console.log('Creating custom field with:', data);
    return this.customFieldModel.create(data);
  }

  async assignCustomFieldValues(values: any[]) {
    return this.customFieldValueModel.bulkCreate(values);
  }

  async getConsumerFields(consumerId: string) {
    return this.customFieldValueModel.findAll({
      where: { consumer_id: consumerId },
      include: [CustomField],
    });
  }
}

// import { Injectable, NotFoundException } from '@nestjs/common';
// import { InjectModel } from '@nestjs/sequelize';
// import { CustomField } from '../models/custom-field.model';
// import { CreateCustomFieldDto } from './dto/create-custom-field.dto';
// import { UpdateCustomFieldDto } from './dto/update-custom-field.dto';

// @Injectable()
// export class CustomFieldsService {
//   constructor(
//     @InjectModel(CustomField)
//     private readonly customFieldModel: typeof CustomField,
//   ) {}

//   async create(dto: CreateCustomFieldDto) {
//     return this.customFieldModel.create(dto as any);
//   }

//   async findAll() {
//     return this.customFieldModel.findAll();
//   }

//   async findOne(id: string) {
//     const field = await this.customFieldModel.findByPk(id);
//     if (!field) throw new NotFoundException('Custom field not found');
//     return field;
//   }

//   async update(id: string, dto: UpdateCustomFieldDto) {
//     const field = await this.findOne(id);
//     return field.update(dto);
//   }

//   async remove(id: string) {
//     const field = await this.findOne(id);
//     await field.destroy();
//     return { message: 'Custom field deleted' };
//   }
// }

import { Injectable, Scope, Inject } from '@nestjs/common';
import { Sequelize } from 'sequelize-typescript';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';

import { Consumer } from '../models/consumer.model';
import { CustomField } from '../models/custom-field.model';

@Injectable({ scope: Scope.REQUEST })
export class SequelizeSchemaService {
  private schema: string;

  constructor(
    @Inject(REQUEST) private readonly req: Request,
    private readonly sequelize: Sequelize,
  ) {
    this.schema = req['schema'];
  }

  async getModel<T>(model: any): Promise<any> {
    return model.schema(this.schema);
  }

  async findAllConsumers() {
    const ConsumerModel = await this.getModel(Consumer);
    return ConsumerModel.findAll();
  }
}

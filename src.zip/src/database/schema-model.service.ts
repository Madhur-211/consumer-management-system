import { Injectable, Scope } from '@nestjs/common';
import { Sequelize } from 'sequelize-typescript';
import { User } from '../models/user.model';
import { Consumer } from '../models/consumer.model';
import { ConsumerCustomFieldValue } from '../models/consumer-custom-field-value.model';

@Injectable({ scope: Scope.REQUEST })
export class SchemaModelService {
  constructor(private sequelize: Sequelize) {}

  getModel<T>(model: any, schema: string): T {
    return this.sequelize.define(model.name, model.getAttributes(), {
      ...model.options,
      tableName: model.tableName,
      modelName: model.name,
      schema: schema,
      timestamps: model.options.timestamps,
    }) as any as T;
  }
}

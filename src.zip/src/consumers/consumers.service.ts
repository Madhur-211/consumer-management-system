import {
  flatten,
  Injectable,
  NotFoundException,
  Scope,
  Inject,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Consumer } from '../models/consumer.model';
import { CreateConsumerDto } from './dto/create-consumer.dto';
import { Request } from 'express';
import { REQUEST } from '@nestjs/core';

@Injectable({ scope: Scope.REQUEST })
export class ConsumersService {
  constructor(
    @InjectModel(Consumer)
    private consumerModel: typeof Consumer,
    @Inject(REQUEST) private readonly request: Request,
  ) {}

  private get schema() {
    const s = this.request['schema'];
    console.log('Current tenant schema in ConsumersService:', s);
    return s;
  }

  async create(
    createConsumerDto: CreateConsumerDto,
    userId: string,
  ): Promise<Consumer> {
    const existing = await this.consumerModel.schema(this.schema).findOne({
      where: { phone: createConsumerDto.phone },
    });

    if (existing) {
      throw new Error(
        `Consumer with phone number ${createConsumerDto.phone} already exists.`,
      );
    }

    return await this.consumerModel.schema(this.schema).create({
      ...createConsumerDto,
      created_by: userId,
      updated_by: userId,
    } as any);
  }

  findAll() {
    return this.consumerModel.schema(this.schema).findAll({ paranoid: false });
  }

  findOne(consumer_id: string) {
    return this.consumerModel.schema(this.schema).findByPk(consumer_id);
  }

  async update(consumer_id: string, dto: Partial<CreateConsumerDto>) {
    try {
      return await this.consumerModel.schema(this.schema).update(dto, {
        where: { consumer_id },
        returning: true,
      });
    } catch (error) {
      console.error('Update Consumer Error:', error);
      throw error;
    }
  }

  async remove(id: string): Promise<number> {
    try {
      return await this.consumerModel
        .schema(this.schema)
        .destroy({ where: { consumer_id: id } });
    } catch (error) {
      console.error('Delete Consumer Error:', error);
      throw error;
    }
  }

  async blockConsumer(id: string): Promise<Consumer> {
    const consumer = await this.consumerModel.schema(this.schema).findByPk(id);
    if (!consumer) throw new NotFoundException('Consumer not found');

    consumer.is_blocked = true;
    await consumer.save();
    return consumer;
  }

  async unblockConsumer(id: string): Promise<Consumer> {
    const consumer = await this.consumerModel.schema(this.schema).findByPk(id);
    if (!consumer) throw new NotFoundException('Consumer not found');

    consumer.is_blocked = false;
    await consumer.save();
    return consumer;
  }

  async markAsTestConsumer(id: string): Promise<Consumer> {
    const consumer = await this.consumerModel.schema(this.schema).findByPk(id);
    if (!consumer) throw new NotFoundException('Consumer not found');

    consumer.is_test_consumer = true;
    await consumer.save();
    return consumer;
  }

  async unmarkAsTestConsumer(id: string): Promise<Consumer> {
    const consumer = await this.consumerModel.schema(this.schema).findByPk(id);
    if (!consumer) throw new NotFoundException('Consumer not found');

    consumer.is_test_consumer = false;
    await consumer.save();
    return consumer;
  }
}
